// =========================
// server.js
// =========================

// 1. Load environment variables
require('dotenv').config();

// 2. Imports
const express = require('express');
const path = require('path');
const fetch = require('node-fetch');

// 3. Initialize Express
const app = express();
app.use(express.json());
app.use(express.static(__dirname)); // Serve index.html, app.js, style.css, etc.

// 4. Read environment variables
const STORE = process.env.SHOPIFY_STORE; // e.g., priceoptimaai.myshopify.com
const ADMIN_API_ACCESS_TOKEN = process.env.SHOPIFY_ADMIN_API_ACCESS_TOKEN;
const API_VERSION = process.env.SHOPIFY_API_VERSION || '2025-07';

// Sanity check
if (!STORE || !ADMIN_API_ACCESS_TOKEN) {
  console.error('❌ Missing SHOPIFY_STORE or SHOPIFY_ADMIN_API_ACCESS_TOKEN in .env');
  process.exit(1);
}

// 5. Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    ok: true,
    time: new Date().toISOString(),
    store: STORE,
    apiVersion: API_VERSION
  });
});

// 6. Get all products + variants
app.get('/api/get-products', async (req, res) => {
  try {
    const url = `https://${STORE}/admin/api/${API_VERSION}/products.json`;
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'X-Shopify-Access-Token': ADMIN_API_ACCESS_TOKEN,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`Shopify API request failed: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();

    const products = data.products.map(product => ({
      id: product.id,
      title: product.title,
      variants: product.variants.map(variant => ({
        id: variant.id,
        sku: variant.sku,
        price: variant.price
      }))
    }));

    res.json({ ok: true, products });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// 7. Update Shopify product price
app.post('/api/sync-shopify-price', async (req, res) => {
  try {
    const { sku, variantId, newPrice } = req.body;

    if (!sku && !variantId) {
      return res.status(400).json({ ok: false, error: 'Provide sku or variantId' });
    }
    if (!newPrice) {
      return res.status(400).json({ ok: false, error: 'Provide newPrice' });
    }

    let targetVariantId = variantId;

    // Lookup variant ID by SKU if not provided
    if (!targetVariantId && sku) {
      const lookupUrl = `https://${STORE}/admin/api/${API_VERSION}/products.json?fields=variants&limit=250`;
      const lookupRes = await fetch(lookupUrl, {
        method: 'GET',
        headers: {
          'X-Shopify-Access-Token': ADMIN_API_ACCESS_TOKEN,
          'Content-Type': 'application/json'
        }
      });
      const lookupData = await lookupRes.json();

      for (const product of lookupData.products) {
        for (const variant of product.variants) {
          if (variant.sku === sku) {
            targetVariantId = variant.id;
            break;
          }
        }
        if (targetVariantId) break;
      }

      if (!targetVariantId) {
        return res.status(404).json({ ok: false, error: `Variant with SKU ${sku} not found` });
      }
    }

    // Update price
    const updateUrl = `https://${STORE}/admin/api/${API_VERSION}/variants/${targetVariantId}.json`;
    const updateRes = await fetch(updateUrl, {
      method: 'PUT',
      headers: {
        'X-Shopify-Access-Token': ADMIN_API_ACCESS_TOKEN,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        variant: { id: targetVariantId, price: newPrice }
      })
    });

    if (!updateRes.ok) {
      throw new Error(`Failed to update price: ${updateRes.status} ${updateRes.statusText}`);
    }

    const updateData = await updateRes.json();
    res.json({ ok: true, updatedVariant: updateData.variant });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// 8. Start server
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`✅ Local server running at http://localhost:${PORT}`);
  console.log(`➡  Open http://localhost:${PORT}/index.html`);
});
